��javax/microedition/lcdui/Form�滻Ϊkavax/microedition/lcdui/Fork
��javax/microedition/lcdui/TextBox�滻Ϊkavax/microedition/lcdui/TextBok
��javax/microedition/lcdui/TextField�滻Ϊkavax/microedition/lcdui/TextFielk
��javax/microedition/midlet/MIDlet�滻Ϊkavax/microedition/lcdui/MIDtxt